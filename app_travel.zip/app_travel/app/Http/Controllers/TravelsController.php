<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Travel;
use Illuminate\Support\Facades\Storage;

class TravelsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $travels = Travel::paginate(2);
        return view('travels.index',['travels' => $travels]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('travels.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //validasi
        $request->validate([
           'nama' => 'required',
           'kota' => 'required',
           'harga_tiket' => 'required',
           'image' => 'required|image|mimes:jpg,jpeg,png,svg,gif|max:2048'
        ]);
        $image = $request->file('image');
        $image->storeAs('public/images/', $image->hashName());
        //simpan
        Travel::create([
            'nama' => $request->nama,
            'kota' => $request->kota,
            'harga_tiket' => $request->harga_tiket,
            'image' => $image->hashName(),
        ]);
        //redirect
        return redirect()->route('travel.index')->with('success','Travel Add successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Travel $travel)
    {
        return view('travels.show',['travel' => $travel]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Travel $travel)
    {
        return view('travels.edit',['travel' => $travel]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Travel $travel)
    {
        //validasi
        $request->validate([
            'nama' => 'required',
            'kota' => 'required',
            'harga_tiket' => 'required'
         ]);
         if ($request->has('image')) {
            $image = $request->file('image');
            $image->storeAs('public/images/', $image->hashName());
            Storage::delete('public/images' . $travel->image);

             //simpan
         $travel->update([
            'nama' => $request->nama,
            'kota' => $request->kota,
            'harga_tiket' => $request->harga_tiket,
            'image' => $image->hashName(),
         ]);
         } else {
            $travel->update([
            'nama' => $request->nama,
            'kota' => $request->kota,
            'harga_tiket' => $request->harga_tiket,
            ]);
         }

         //redirect
         return redirect()->route('travel.index')->with('success','Travel update successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Travel $travel)
    {
        Storage::delete('public/images/' . $travel->image);
        $travel->delete();
        return redirect()->route('travel.index')->with('success','Travel delete successfully');
    }
}
