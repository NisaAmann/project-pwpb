<?php $__env->startSection('content'); ?>
<img src="<?php echo e(Storage::url('public/images/' . $travel->image)); ?>" alt="" style="width: 150px">
<h3><?php echo e($travel->nama); ?></h3>
<p><?php echo e($travel->kota); ?></p>
<p><?php echo e($travel->harga_tiket); ?></p>
<a href="<?php echo e(route('travel.index')); ?>" class="btn btn-secondary">Back To Index</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('travels.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/app_travel/resources/views/travels/show.blade.php ENDPATH**/ ?>