@extends('travels.layout')
@section('content')
<img src="{{ Storage::url('public/images/' . $travel->image) }}" alt="" style="width: 150px">
<h3>{{ $travel->nama}}</h3>
<p>{{ $travel->kota}}</p>
<p>{{ $travel->harga_tiket}}</p>
<a href="{{ route('travel.index') }}" class="btn btn-secondary">Back To Index</a>
@endsection
