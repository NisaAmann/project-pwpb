@extends('travels.layout')
@section('content')

<a class= 'btn btn-primary' href="{{ route('travel.create') }}">Add New</a><br><br>

<table class="table table-bordered bordered-dark table-hover table-stripped">
<tr>
    <th>Id</th>
    <th>Image</th>
    <th>Nama</th>
    <th>Kota</th>
    <th>Harga Tiket</th>


    @foreach ($travels as $travel)
     <tr>
        <td>{{ $travel->id }}</td>
        <td><img src="{{ Storage::url('public/images/' . $travel->image) }}" alt="" style="width: 150px;">
        </td>
        <td>{{ $travel->nama }}</td>
        <td>{{ $travel->kota }}</td>
        <td>{{ $travel->harga_tiket }}</td>
        <td>
            <a class="btn btn-warning" href="{{ route('travel.show',$travel->id)}}">Show</a>
            <a class="btn btn-success" href="{{ route('travel.edit',$travel->id)}}">Update</a>
            <form onclick=" return confirm('Are you Sure?')"action="{{ route('travel.destroy', $travel->id) }}" method="post" style="display: inline">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger">Delete</button>
            </form>
        </td>
     </tr>
    @endforeach
</tr>
</table>
{{ $travels->links() }}
@endsection
