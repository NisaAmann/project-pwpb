@extends('travels.layout')
@section('content')
<form class="form"action="{{ route('travel.update',$travel->id) }}" method="post" enctype="multipart/form-data">
@csrf
@method('PUT')
<label for="">Nama</label><br>
<input type="text" name="nama" id="" value="{{ $travel->nama }}"><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id="" value="{{ $travel->kota }}"><br>

<label for="">Harga Tiket</label><br>
<input type="number" name="harga_tiket" id="" value="{{ $travel->harga_tiket }}"><br>

<label for="">Upload Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Save" class="btn btn-secondary">

</form>
@endsection
